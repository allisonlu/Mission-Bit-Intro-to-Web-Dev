# Phaser Template

Minimal template to start a [Phaser](http://phaser.io/) project with.

Phaser resources:

* [Documentation](http://docs.phaser.io/)
* [Examples](http://examples.phaser.io)
* [Forum](http://html5gamedevs.com/forum/14-phaser/)

To download this template, click "Download Zip" on the right side of this page.
