images from https://github.com/kirualex/SprityBird/tree/master/spritybird/Resources
